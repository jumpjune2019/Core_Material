// modified to use toggle button
// forcing a width to the button when it toggles and text change, it does not change it's actual size
// ensure you are using setPreferredSize(Dimension);

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.*;

// public class GridLayoutDemo implements ActionListener {
public class GridLayoutDemo implements ItemListener {
	 	
   private JFrame mainFrame;
   private JLabel headerLabel;
   private JLabel statusLabel;
   private JPanel controlPanel;

   public GridLayoutDemo(){
      prepareGUI();
   }
   
   private void prepareGUI(){
      mainFrame = new JFrame("Grid Layout Example");
      mainFrame.setSize(500,400);
      mainFrame.setLayout(new GridLayout(3, 1));
      headerLabel = new JLabel("",JLabel.CENTER );
      statusLabel = new JLabel("",JLabel.CENTER);
      statusLabel.setSize(350,100);
      
      // old school way to close a window
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
             // this is the way to force a java application to gracefully exit
        	 // when not going to end via the main method entry point
        	 System.exit(0);
         }        
      });    
      controlPanel = new JPanel();
      controlPanel.setLayout(new FlowLayout());

      mainFrame.add(headerLabel);
      mainFrame.add(controlPanel);
      mainFrame.add(statusLabel);
      mainFrame.setVisible(true);  
   }
   
   private void showGridLayoutDemo() throws NullPointerException {
      headerLabel.setText("Layout in action: GridLayout");      
      statusLabel.setText("Press a button, I dare you...");
      JPanel panel = new JPanel();
      panel.setBackground(Color.CYAN);
      panel.setSize(400,300);
      GridLayout layout = new GridLayout(2,3);
      layout.setHgap(10);
      layout.setVgap(10);
      panel.setLayout(layout);
      int length = 6;
      JToggleButton[] buttons = new JToggleButton[length];
      JLabel[] labels = new JLabel[length];
      JPanel[] panels = new JPanel[length];
      int x;
      String prefixLabel = "Button ";
      for (x = 0; x < length; x++) {
    	  buttons[x] = new JToggleButton(prefixLabel.concat(Integer.toString(x + 1)));
    	  buttons[x].addItemListener(this);
    	  labels[x] = new JLabel(prefixLabel.concat(Integer.toString(x + 1)), JLabel.CENTER);
    	  panels[x] = new JPanel();
    	  panels[x].setLayout(new GridLayout(2, 1));
    	  panels[x].setSize(120, 50);
    	  buttons[x].setPreferredSize(new Dimension(100, 30));
    	  panels[x].add(buttons[x]);
    	  panels[x].add(labels[x]);
    	  // panel.add(buttons[x]);

    	  panel.add(panels[x]);
      }
      
      controlPanel.add(panel);
      mainFrame.setVisible(true);  
   }

//   public void actionPerformed(ActionEvent ae) {
//	   
//   }
//   
  
   public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				GridLayoutDemo gridLayoutDemo = new GridLayoutDemo();  
			    gridLayoutDemo.showGridLayoutDemo();
			}
		});      
   }

	@Override
	public void itemStateChanged(ItemEvent e) {
		JToggleButton btn = (JToggleButton) e.getItem();
		if(btn.isSelected()) {
			btn.setText("Button XXX");
		} else {
			btn.setText("Button X");
		}
		
	}


}