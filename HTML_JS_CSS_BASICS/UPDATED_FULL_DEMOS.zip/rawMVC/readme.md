#Demo - JavaScript Test Exercise (Custom MVC)


##Languages

This demo is written in pure Javascript, There are no libraries of any kind being used.

##Browsers

This was tested on a Windows 7 PC with the following browsers:

* Firefox 43.0.1
* Chrome 47.0.2526.106 m

##Documentation

A PDF documentation is available at the root of the project.

##Live Version

This app is available via the following link:
http://www.claudegauthier.net/demos/Broadridge/index.html


##Tools

Use TextPad for content creation and editing.

