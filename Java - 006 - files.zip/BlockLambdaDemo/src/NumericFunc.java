// A block lambda that finds the smallest positive factor
// of an int value.
interface NumericFunc {
	int func(int n);
}