
interface MyParamValue {
	double getValue(double v);
}
