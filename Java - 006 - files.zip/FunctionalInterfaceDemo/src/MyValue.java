
interface MyValue {
	double getValue();
}
