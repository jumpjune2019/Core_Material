interface StringTest {
	boolean test(String aStr, String bStr);
}