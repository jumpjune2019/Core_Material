interface SomeTest<T> {
	boolean test(T n, T m);
}
