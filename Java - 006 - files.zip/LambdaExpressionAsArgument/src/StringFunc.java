interface StringFunc {
	String func(String str);
}