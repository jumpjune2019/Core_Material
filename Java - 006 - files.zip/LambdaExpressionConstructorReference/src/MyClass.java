class MyClass {
	private String str;
	// This constructor takes an argument.
	MyClass(String s) { str = s; }
	// This is the default constructor.
	MyClass() { str = ""; }
	// ...
	String getStr() { return str; }
}