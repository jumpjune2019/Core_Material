interface MyFunc {
	MyClass func(String s);
}
