interface MyFunc {
	int func(int n);
}
