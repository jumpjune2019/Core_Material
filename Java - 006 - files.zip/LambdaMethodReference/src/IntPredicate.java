
interface IntPredicate {
	boolean test(int n);
}
