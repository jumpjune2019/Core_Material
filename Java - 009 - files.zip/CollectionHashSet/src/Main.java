import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Main {

	// https://www.callicoder.com/java-hashset/
	public static void main(String[] args) {
		//Creating HashSet and adding elements  
		HashSet<String> set=new HashSet<String>();  
		set.add("Claude");  
		set.add("Rich");  
		set.add("Claude");  
		set.add("Courtney");  
		//Traversing elements  
		Iterator<String> itr=set.iterator();  
		while(itr.hasNext()){  
			System.out.println(itr.next());  
		}  
		
		System.out.println("\n\n");
		
		// Creating a HashSet
        HashSet<String> daysOfWeek = new HashSet<>();

        // Adding new elements to the HashSet
        daysOfWeek.add("Monday");
        daysOfWeek.add("Tuesday");
        daysOfWeek.add("Wednesday");
        daysOfWeek.add("Thursday");
        daysOfWeek.add("Friday");
        daysOfWeek.add("Saturday");
        daysOfWeek.add("Sunday");

        // Adding duplicate elements will be ignored
        daysOfWeek.add("Monday");

        System.out.println(daysOfWeek);
	}
}
