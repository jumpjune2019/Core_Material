
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Stack;

public class Main {

	// https://www.callicoder.com/java-priority-queue/
	public static void main(String args[]) {  
	
		PriorityQueue<String> queue=new PriorityQueue<String>();  
		queue.add("Claude Gauthier");  
		queue.add("Rich Bowers");  
		queue.add("Courtney Heinrich");  
		queue.add("Charles Dunn");  
		System.out.println("head:"+ queue.element());  
		System.out.println("head:"+ queue.peek());  
		System.out.println("iterating the queue elements:");  
		Iterator itr = queue.iterator();  
		while(itr.hasNext()){  
			System.out.println(itr.next());  
		}  
		queue.remove();  
		queue.poll();  
		System.out.println("after removing two elements:");  
		Iterator<String> itr2 = queue.iterator();  
		while(itr2.hasNext()){  
			System.out.println(itr2.next());  
		}  

		// more demo
		// Create a Priority Queue
		System.out.println("\n\n");
        PriorityQueue<Integer> numbers = new PriorityQueue<>();

        // Add items to a Priority Queue (ENQUEUE)
        numbers.add(750);
        numbers.add(500);
        numbers.add(900);
        numbers.add(100);

        // Remove items from the Priority Queue (DEQUEUE)
        while (!numbers.isEmpty()) {
            System.out.println(numbers.remove());
        }
        
        System.out.println("\n\nAn Empty Queue will be an empty array object");
        System.out.println(numbers);
        
		// Strings
        
        System.out.println("\n\n");
        // Create a Priority Queue
        PriorityQueue<String> namePriorityQueue = new PriorityQueue<>();

        // Add items to a Priority Queue (ENQUEUE)
        namePriorityQueue.add("Lisa");
        namePriorityQueue.add("Robert");
        namePriorityQueue.add("John");
        namePriorityQueue.add("Chris");
        namePriorityQueue.add("Angelina");
        namePriorityQueue.add("Joe");

        // Remove items from the Priority Queue (DEQUEUE)
        while (!namePriorityQueue.isEmpty()) {
            System.out.println(namePriorityQueue.remove());
        }
	}
}