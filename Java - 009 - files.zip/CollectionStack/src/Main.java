
import java.util.Iterator;
import java.util.Stack;

public class Main {

	// https://www.callicoder.com/java-stack/
	public static void main(String args[]) {  
	
		Stack<String> stack = new Stack<String>();  
		stack.push("Claude");  
		stack.push("Rich");  
		stack.push("Courtney");  
		stack.push("Charles");  
		stack.push("Sierra");  
		
		Iterator<String> itr = stack.iterator();  
		while(itr.hasNext()){  
			System.out.println(itr.next());  
		}
		System.out.println("\n");
		stack.pop();  // this will pop Sierra

		Iterator<String> itr2 = stack.iterator();
		while(itr2.hasNext()){  
			System.out.println(itr2.next());  
		}

		// Next Example
		System.out.println("\n\n");
		Stack<String> stackOfCards = new Stack<>();

        // Pushing new items to the Stack
        stackOfCards.push("Jack");
        stackOfCards.push("Queen");
        stackOfCards.push("King");
        stackOfCards.push("Ace");

        System.out.println("Stack => " + stackOfCards);
        System.out.println();

        // Popping items from the Stack
        String cardAtTop = stackOfCards.pop();  // Throws EmptyStackException if the stack is empty
        System.out.println("Stack.pop() => " + cardAtTop);
        System.out.println("Current Stack => " + stackOfCards);
        System.out.println();

        // Get the item at the top of the stack without removing it
        cardAtTop = stackOfCards.peek();
        System.out.println("Stack.peek() => " + cardAtTop);
        System.out.println("Current Stack => " + stackOfCards);
		
	}
}