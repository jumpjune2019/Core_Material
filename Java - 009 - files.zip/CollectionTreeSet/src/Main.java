import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;


public class Main {

	// https://www.callicoder.com/java-treeset/
	public static void main(String[] args) {

		//Creating and adding elements  
		TreeSet<String> set=new TreeSet<String>();  
		set.add("Claude");  
		set.add("Rich");  
		set.add("Claude");  
		set.add("Courtney");  
		//traversing elements  
		Iterator<String> itr=set.iterator();  
		while(itr.hasNext()){  
			System.out.println(itr.next());  
		}  		
		
		System.out.println("\n\n");
		
		// Creating a TreeSet using SortedSet
        SortedSet<String> fruits = new TreeSet<>();

        // Adding new elements to a TreeSet
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Pineapple");
        fruits.add("Orange");

        System.out.println("Fruits Set : " + fruits);

        // Duplicate elements are ignored
        fruits.add("Apple");
        System.out.println("After adding duplicate element \"Apple\" : " + fruits);

        // This will be allowed because it's in lowercase.
        fruits.add("banana");
        System.out.println("After adding \"banana\" : " + fruits);
		
	}
}

