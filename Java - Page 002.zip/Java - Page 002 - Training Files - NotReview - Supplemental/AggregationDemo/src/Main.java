
public class Main {

	public static void main(String[] args) {
		int x[] = { 3, 2, 1, 5, 6, 7, 9, 8, 10};
		Aggregation ag = new Aggregation(x);
		
		ag.analyze();

	}

}
