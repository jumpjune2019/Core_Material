
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double i, j, d;
		i = 5;
		j = 10;
		if(i != 0) {
			System.out.println("i does not equal 0");
			d = j / i;
			System.out.println("j / i is: " + d);
		}
			
	}

}
