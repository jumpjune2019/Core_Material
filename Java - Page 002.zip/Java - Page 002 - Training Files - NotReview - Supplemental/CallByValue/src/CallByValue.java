
public class CallByValue {

	void NoChange(int i, int j) {
		i = i + j;
		j = -j;
	}

}
