
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch;
		
		ch = 'X';
		
		System.out.println("ch contains: " + ch);
		
		System.out.println();
		
		ch++;
		
		System.out.println("ch contains: " + ch);
		
		System.out.println();

		ch = 90;
		
		System.out.println("ch contains: " + ch);
		
		System.out.println();
		
		
	}

}
