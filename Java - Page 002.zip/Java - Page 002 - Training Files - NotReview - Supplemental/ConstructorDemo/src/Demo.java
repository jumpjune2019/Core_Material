public class Demo {
	int x;
	public Demo() {
		x = 10;
	}
}
