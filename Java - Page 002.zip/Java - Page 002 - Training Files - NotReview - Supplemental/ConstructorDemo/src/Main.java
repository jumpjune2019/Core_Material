public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo test = new Demo();
		System.out.println("x is: " + test.x);
	}
}
