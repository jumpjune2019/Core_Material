package def;

public class MyIFImp implements MyIF {

	@Override
	public int getUserID() {
		// TODO Auto-generated method stub
		return 100;
	}

}
