package def;

public class MyIFImp2 implements MyIF {

	@Override
	public int getUserID() {
		return 101;
	}
	
	@Override
	public int getAdminID() {
		return 42;
	}	

}
