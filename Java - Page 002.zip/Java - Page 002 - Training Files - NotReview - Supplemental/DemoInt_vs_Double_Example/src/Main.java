
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int var;
		double x;
		
		var = 10;
		x = 10.0;
		
		System.out.println("Original value of var: " + var);
		System.out.println("Original value of x: " + x);
		System.out.println();
		var = var / 4;
		x = x / 4;
		
		System.out.println("var after division with 4: " + var);
		System.out.println("x after division with 4: " + x);
	}

}
