
public class Err {

	String msg;
	int severity;
	
	public Err(String m, int s) {
		msg = m;
		severity = s;
	}

}
