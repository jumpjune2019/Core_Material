
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, j;
		
		for(i = 0, j = 10; i < j; i++, j--) {
			System.out.println("i and j: " + i + ", " + j);
		}
	}

}
