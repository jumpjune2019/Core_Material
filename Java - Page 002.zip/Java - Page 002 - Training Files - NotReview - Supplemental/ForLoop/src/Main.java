
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count;
		for (count = 0; count < 5; count = count + 1) {
			System.out.println("This is count: " + count);
		}
		System.out.println("Done!");
	}

}
