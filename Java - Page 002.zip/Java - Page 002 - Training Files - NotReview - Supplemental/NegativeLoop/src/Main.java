
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x; 
		for( x = 100; x > -100; x -= 5) {
			System.out.println(x);
		}
	}

}
