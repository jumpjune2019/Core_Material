
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pwr x = new Pwr(4.0, 2);
		Pwr y = new Pwr(2.5, 1);
		Pwr z = new Pwr(5.7, 0);
		
		x.print();
		y.print();
		z.print();
				
	}

}
