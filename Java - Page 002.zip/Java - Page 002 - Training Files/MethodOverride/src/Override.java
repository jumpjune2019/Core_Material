public class Override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B subOb = new B(1, 2, 3);
		subOb.show(); // this calls show() in B
	}

}
