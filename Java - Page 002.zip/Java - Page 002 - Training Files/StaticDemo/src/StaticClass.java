
class StaticClass {

	static int test(int x) {
		
		return x * 2;
		
	}

}
