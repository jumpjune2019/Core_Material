
public class StaticDemo {

	static int count = 0;
	
	public StaticDemo() {
		count++;
	}
	
	int getCount() {
		return count;
	}

}
