public class Main {
	public static void main(String args[]) {
		MyClass myObj = new MyClass("test");
		System.out.println(myObj.getMsg());
	}
}
