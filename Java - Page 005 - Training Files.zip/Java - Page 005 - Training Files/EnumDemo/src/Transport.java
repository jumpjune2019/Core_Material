
enum Transport {
	CAR, TRUCK, AIRPLANE, TRAIN, BOAT
}