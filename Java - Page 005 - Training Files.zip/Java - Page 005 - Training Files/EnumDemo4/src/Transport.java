// Demonstrate ordinal() and compareTo().
// An enumeration of Transport varieties.
enum Transport {
	CAR, TRUCK, AIRPLANE, TRAIN, BOAT
}