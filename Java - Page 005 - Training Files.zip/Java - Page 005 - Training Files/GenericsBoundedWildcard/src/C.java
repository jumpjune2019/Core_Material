
public class C extends A {

}
