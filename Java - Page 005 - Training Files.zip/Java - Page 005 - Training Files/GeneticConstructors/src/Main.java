
public class Main {
	public static void main(String args[]) {
		Summation ob = new Summation(5);
		System.out.println("Summation of 4.0 is " + ob.getSum());
	}
}
