
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer iOb = new Integer(100);
		int i = iOb.intValue();
		System.out.println(i + " " + iOb); // displays 100 100
	}

}
