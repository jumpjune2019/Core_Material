enum Transport {
	CAR(65, "vroom!"), TRUCK(55, "beeep!"), AIRPLANE(600, "fly!"), TRAIN(70, "choo choo!"), BOAT(22, "swish!");
	private int speed; // typical speed of each transport
	private String label;
	private String afterTheFact;
	// Constructor
	Transport(int s, String m) { 
		speed = s; 
		label = m;
	}
	int getSpeed() {
		return speed; 
	}
	
	String returnAllStuff() {
		String fullMessage = String.format("speed = %d and label = %s", speed, label);
		return fullMessage;
	}
	
	void setAfterTheFact(String a) {
		afterTheFact = a;
	}
	
	String getAfterTheFact() {
		return afterTheFact;
	}
}