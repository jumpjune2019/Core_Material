BASIC SCAFFOLDING

The main part of this app is to be able to manage a matrix and associate it to a clients.

startApp();
- This is where I can setup very basic stuff, at least an app intro
getInput();
- get my clients
- get a room matrix
processData();
- associate clients with room matrix
showOutput();
- display matrix 
- display list of clients with seat assignment
endApp();
- display an ending message