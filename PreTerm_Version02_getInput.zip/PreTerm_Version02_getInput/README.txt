In this version we've create a Client class which can hold the data for the user

lastname
firstname
id

From this, we need to build a way to keep a full set of data in an array of Client

We will use a CSV file to do so.